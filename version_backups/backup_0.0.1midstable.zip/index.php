<?php
    session_start();
    if(isset($_SESSION["ip"])) {
        if($_SESSION["ip"]!=$_SERVER["REMOTE_ADDR"]) {
            session_unset();
            session_destroy();
        }
        else {
            header("Location: /user");
        }
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Login to OnlineDesktop</title>
    </head>
    <body>
        <form action="login.php" method="post">
            <label>Username: </label>
            <input type="text" name="username"/><br>
            <label>Password: </label>
            <input type="password" name="password"/><br>
            <input type="submit" value="Login"/>
            
            <label class="err-msg"><?php
                if(isset($_GET["err"])) {
                    echo $_GET["err"];
                }
            ?></label>
        </form>
    </body>
</html>