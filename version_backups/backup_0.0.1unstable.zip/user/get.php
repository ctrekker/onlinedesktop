<?php
    session_start();
    //Make sure all required variables exist
    if(isset($_SESSION["username"])&&isset($_SESSION["password"])&&isset($_SESSION["id"])&&isset($_SESSION["ip"])&&isset($_GET["path"])) {
        //Make sure ip is same as original log in ip (to prevent spoofing)
        if($_SESSION["ip"]==$_SERVER["REMOTE_ADDR"]) {
            $id=$_SESSION["id"];
            $path=$_GET["path"];
            echo file_get_contents("./storage/$id".$path);
        }
    }
?>