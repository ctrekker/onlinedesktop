<?php
    session_start();
    if(isset($_SESSION["ip"])) {
        if($_SESSION["ip"]!=$_SERVER["REMOTE_ADDR"]) {
            session_unset();
            session_destroy();
            header("Location: ../");
        }
    }
    else {
        header("Location: ../");
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <title>OnlineDesktop - <?php echo $_SESSION["username"] ?></title>
        <style>
            html, body {
                margin: 0px;
                padding: 0px;
                width: 100%;
                height: 100%;
            }
            .desktop-container {
                width: 100%;
                height: 100%;
            }
            .os_table {
                width: 100%;
                height: 100%;
            }
        </style>
        <script src="../core/lib/js/jquery.min.js"></script>
        <!--OS Loader-->
        <script type="text/javascript">
            window.onload=function() {
                var user={
                    os_name: "default",
                    os_path: "../core/os/default"
                };
                $.ajax({url: user.os_path+"/main.xml", success: function(result) {
                    panes=result.getElementsByTagName("workspace")[0].childNodes[1].childNodes;
                    var root=null;
                    for (var i=0; i<panes.length; i++) {
                        if(panes[i].nodeType==1) {
                            root=panes[i];
                        }
                    }
                    if (root!=null) {       
                        var table=document.createElement("table");
                        document.getElementById("desktop-environment").appendChild(getTable(root, 0));
                        
                    }
                    else {
                        console.error("Invalid document structure!");
                    }
                    var env=document.getElementById("desktop-environment");
                    var content=document.createElement("table");
                }});
                function getTable(root, level) {
                    var nodes=root.childNodes;
                    var nodeCount=0;
                    var activeNodes=[];
                    var displayRule=root.getAttribute("type");
                    var contentMode=false;
                    for(var i=0; i<nodes.length; i++) {
                        if (nodes[i].nodeType==1) {
                            nodeCount++;
                            activeNodes.push(nodes[i]);
                            if (nodes[i].nodeName=="content") {
                                contentMode=true;
                            }
                        }
                    }
                    if (nodeCount>0) {
                        var table=document.createElement("table");
                        table.setAttribute("level", level);
                        if (displayRule=="hbox") {
                            table.setAttribute("class", "hbox_table os_table");
                            var tr=document.createElement("tr");
                            tr.setAttribute("class", "hbox_tr");
                            for(var i=0; i<nodeCount; i++) {
                                tr.appendChild(document.createElement("td"));
                                tr.lastChild.setAttribute("class", "hbox_td");
                                if(!contentMode) tr.lastChild.appendChild(getTable(activeNodes[i], level+1));
                                else {
                                    getContent(activeNodes[i], tr.lastChild);
                                    tr.style.width=activeNodes[i].getAttribute("ratio");
                                }
                            }
                            table.appendChild(tr);
                        }
                        else if (displayRule=="vbox") {
                            table.setAttribute("class", "vbox_table os_table");
                            for(var i=0; i<nodeCount; i++) {
                                var tr=document.createElement("tr");
                                tr.setAttribute("class", "vbox_tr");
                                var td=document.createElement("td");
                                td.setAttribute("class", "vbox_td");
                                if(!contentMode) td.appendChild(getTable(activeNodes[i], level+1));
                                else {
                                    getContent(activeNodes[i], td);
                                    tr.style.height=activeNodes[i].getAttribute("ratio");
                                }
                                tr.appendChild(td);
                                table.appendChild(tr);
                            }
                        }
                        else {
                            console.log(displayRule);
                            console.log(root);
                        }
                        return table;
                    }
                    else {
                        throw new Error("Failed to insert content!");
                    }
                }
                function getContent(node, writeNode) {
                    var source=node.getAttribute("source");
                    var path="/os/sources/"+source;
                    var type=node.getAttribute("type");
                    $.ajax({url: "get.php?path="+path, success: function(result) {
                        var xml=$.parseXML(result);
                        var source=xml.getElementsByTagName("source")[0];
                        var activeNodes=[];
                        for(var i=0; i<source.childNodes.length; i++) {
                            var value=source.childNodes[i];
                            if (value.nodeType==1) {
                                activeNodes.push(value);
                            }
                        }
                        
                        if (activeNodes.length>0) {
                            var table=document.createElement("table");
                            table.setAttribute("class", "content-display os_table");
                            if (node.hasAttribute("tbstyle")) {
                                table.setAttribute("style", node.getAttribute("tbstyle"));
                            }
                            if (type=="hlist") {
                                var tr=document.createElement("tr");
                                tr.setAttribute("class", "hlist_tr");
                                if (node.hasAttribute("trstyle")) {
                                    tr.setAttribute("style", node.getAttribute("trstyle"));
                                }
                                for(var i=0; i<activeNodes.length; i++) {
                                    var td=document.createElement("td");
                                    td.setAttribute("class", "hlist_td");
                                    if (node.hasAttribute("tdstyle")) {
                                        td.setAttribute("style", node.getAttribute("tdstyle"));
                                    }
                                    var val=document.createTextNode(activeNodes[i].childNodes[0].nodeValue);
                                    td.appendChild(val);
                                    tr.appendChild(td);
                                }
                                table.appendChild(tr);
                            }
                            else if (type=="grid") {
                                for (var y=0; y<node.getAttribute("height"); y++) {
                                    var tr=document.createElement("tr");
                                    tr.setAttribute("class", "grid_tr");
                                    if (node.hasAttribute("trstyle")) {
                                        tr.setAttribute("style", node.getAttribute("trstyle"));
                                    }
                                    for(var x=0; x<node.getAttribute("width"); x++) {
                                        var td=document.createElement("td");
                                        td.setAttribute("class", "grid_td");
                                        if (node.hasAttribute("tdstyle")) {
                                            td.setAttribute("style", node.getAttribute("tdstyle"));
                                        }
                                        tr.appendChild(td);
                                    }
                                    table.appendChild(tr);
                                }
                                for(var i=0; i<activeNodes.length; i++) {
                                    var val=activeNodes[i];
                                    var x=parseInt(val.getAttribute("pos").split(",")[0]);
                                    var y=parseInt(val.getAttribute("pos").split(",")[1]);
                                    table.getElementsByTagName("tr")[x].getElementsByTagName("td")[y].appendChild(val);
                                }
                                console.log(table);
                            }
                            writeNode.appendChild(table);
                        }
                    }});
                }
            }
        </script>
    </head>
    <body>
        <div class="desktop-container" id="desktop-environment">
            
        </div>
    </body>
</html>